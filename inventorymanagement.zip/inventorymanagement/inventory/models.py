from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext as _
from django.core.validators import MaxValueValidator, MinValueValidator

class User(AbstractUser):
    pass


class Inventory(models.Model):
    inventory_name=models.CharField(max_length=64,unique=True)
    inventory_address=models.CharField(max_length=64,blank=True)    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="user_inventory",default=1)

    # or even better with formatting
    def __repr__(self):
        return f"Inventory( inventory_name: {self.inventory_name}, inventory_address: {self.inventory_address}, user: {self.user})"

class Category(models.Model):
    inventory = models.ForeignKey(Inventory, on_delete=models.CASCADE, related_name="inventory_category")
    category_name=models.CharField(max_length=64)
    category_description=models.CharField(max_length=64)


Status_Chocies = (
    ('out','Out of stock'),
    ('less', 'Less than minimum'),
    ('available','Available')    
)

class Item(models.Model):
    inventory=models.ForeignKey(Inventory, on_delete=models.CASCADE, related_name="inventory_item")
    item_category= models.ForeignKey(Category, on_delete=models.CASCADE, related_name="category_item")
    item_name=models.CharField(max_length=64)
    item_manufacturer=models.CharField(max_length=64)
    item_color=models.CharField(max_length=64,blank=True)
    item_price=models.IntegerField(blank=True)
    item_weight=models.IntegerField(blank=True)
    item_weight_unit=models.CharField(max_length=64,blank=True)
    item_Dimension=models.CharField(max_length=64)
    item_storage_location=models.CharField(max_length=64)
    item_quantity=models.IntegerField(blank=True)
    item_min_quantity=models.IntegerField(blank=True)
    item_status= models.CharField(max_length=10, choices=Status_Chocies, default='green')

    def checkstatus(self):  
        if self.item_quantity == 0:
            return Status_Chocies[0]      
        elif self.item_quantity < self.item_min_quantity:
            return Status_Chocies[1]
        else:
            return Status_Chocies[2]