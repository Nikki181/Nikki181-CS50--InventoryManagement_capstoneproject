from django.urls import path

from . import views

urlpatterns = [
    path("index", views.index, name="index"),
    path("", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("register", views.register, name="register"),

    # Create new category, item and inventory
    path("create-inventory", views.createinventory, name="createinventory"),
    path("create-category", views.createcategory, name="createcategory"),
    path("create-item", views.createitem, name="createitem"),

    path("change_inventory/<int:inv_id>", views.change_inventory, name="changeinventory"),
    # path("change_inventory/<int:inv_id>", views.change_inventory, name="changeinventory"),
    path("change_category/<int:cat_id>", views.change_category, name="changecategory"),
    path("change_status/<str:status>", views.change_status, name="changestatus"),

    path("select-item",views.select_item,name="selectitem"),
    path("edit-item/<int:item_id>",views.edit_item,name="edititem"),
    path("select-inventory",views.select_inventory,name="selectinventory"),
    path("edit-inventory/<int:inv_id>",views.edit_inventory,name="editinventory"),
    path("select-category",views.select_category,name="selectcategory"),
    path("edit-category/<int:cat_id>",views.edit_category,name="editcategory"),

    path("remove-inventory",views.remove_inventory,name="removeinventory"),
    path("remove-category",views.remove_category,name="removecategory"),
    path("remove-item",views.remove_item,name="removeitem"),

    path("apply-filter",views.apply_filter,name="applyfilter"),
    path("view-notification", views.view_notification , name="viewnotification")


]
