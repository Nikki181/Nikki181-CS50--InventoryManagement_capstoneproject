from django.shortcuts import render
from .models import User,Inventory,Category,Item
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError
from django.contrib.sessions.models import Session
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render,redirect
from django.urls import reverse
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Q

# Create your views here.
@login_required
def index(request):
    userid = request.session.get('userid')     
    # User inventories
    inventory_all = Inventory.objects.filter(user_id=userid)

    if len(inventory_all) == 0 :
        firstinv_id=None
    else:
        firstinv_id = inventory_all[0]
        
    # Fetch all the category based on selected inventory
    cat_all = Category.objects.filter(inventory_id=firstinv_id)
    if len(cat_all) == 0:
        inv_catid=None
    else:
        inv_catid=cat_all[0]
    # Fetch all the items based on the selected inventory
    item  = Item.objects.filter(inventory_id=firstinv_id)

    invs=[]  
    primary_inv={}
    catobj=[]
    itemobj=[]

    for i in range(len(inventory_all)):      
        if inventory_all[i].id== firstinv_id.id:
            active = "active"
            primary_inv = [{"id": inventory_all[i].id, "name": inventory_all[i].inventory_name, "address": inventory_all[i].inventory_address}]
            request.session['current_inv_id']=int(inventory_all[i].id)
        else:
            active = ""
            
        invs.append({"id": inventory_all[i].id, "inventory_name": inventory_all[i].inventory_name, "active": active, "inventory_address": inventory_all[i].inventory_address})
    
    for cat in cat_all:
        catobj.append({"id":cat.id , "category_name": cat.category_name, "category_description":cat.category_description , "inventory_id" : cat.inventory_id})

    for i in item:
        itemobj.append({
            "id":i.id,
            "item_name":i.item_name,
            "item_manufacturer" : i.item_manufacturer,
            "item_color" : i.item_color,
            "item_price": i.item_price,
            "item_weight" : i.item_weight,
            "item_Dimension" : i.item_Dimension,
            "item_storage_location":i.item_storage_location,
            "item_status":i.item_status,
            "inventory_id":i.inventory_id,
            "item_category_id":i.item_category_id,
            "item_min_quantity":i.item_min_quantity,
            "item_quantity":i.item_quantity,
            "item_weight_unit":i.item_weight_unit
        })
    
    # Set to use later
    request.session["invs"] = invs
    if primary_inv != {}:
        request.session["primary_inv"] = primary_inv[0]
    else:
        request.session["primary_inv"] = None
    request.session["items"] = itemobj
    request.session['cats'] = catobj
   
    return render(request, "inventory/index.html", {
        'invs': invs,
        'primary_inv':request.session.get('primary_inv'),
        'items': item,
        'item_count' : len(item),
        'cats':cat_all,
        'cat_count': len(cat_all),
        'filteredcat':cat_all,
        'selectedstatus' : "All"     
    })
    
def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)
        # localStorage.setItem("userid", user.id)
        # Check if authentication successful
        if user is not None:
            login(request, user)
            request.session['userid'] = user.id       
            return HttpResponseRedirect(reverse("index"))
            
        else:
            return render(request, "inventory/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "inventory/login.html")

def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("login"))

def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "inventory/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()

            # Create intial inventory
            inventory_name=request.POST["inventory-name"]
            inventory_address=request.POST["inventory-address"]
            inventory = Inventory()
            inventory.inventory_name = inventory_name
            inventory.inventory_address = inventory_address
            inventory.user_id=user.id
            inventory.save()
        except Exception as e:
            return render(request, "inventory/register.html", {
                "message": e
            })
        login(request, user)
        return render(request, "inventory/login.html")
    else:
        return render(request, "inventory/register.html")

@login_required
def createinventory(request):
    userid = request.session.get('userid')
    if request.method == 'POST':
        try:
            inventory_name=request.POST["inventory-name"]
            inventory_address=request.POST["inventory-address"]
            
            newinv=Inventory()
            newinv.inventory_name = inventory_name
            newinv.inventory_address=inventory_address
            newinv.user_id=userid
            newinv.save() 
        except Exception as e:
            return render(request, "inventory/register.html", {
                "message": e
            })                  
        return redirect('index')
    else:
        return render(request, "inventory/create-inventory.html")

@login_required
def createcategory(request):
    
    if request.method == 'POST':
        try:
            category_name=request.POST["category-name"]
            category_description=request.POST["category_description"]
            
            newcat=Category()
            newcat.category_name = category_name
            newcat.category_description=category_description
            newcat.inventory_id=request.POST["allinventory"]
            newcat.save() 
        except Exception as e:
            return render(request, "inventory/login.html", {
                "message": e
            })                  
        return redirect('index')
    else:        
        userid = request.user.id    
        inventory_all = Inventory.objects.filter(user_id=userid)
        if len(inventory_all) == 0 :
            firstinv_id=None
        else:
            firstinv_id = inventory_all[0]

        invs=[]
        primary_inv={}

        for i in range(len(inventory_all)):      
            if inventory_all[i].id== firstinv_id.id:
                active = "active"
                primary_inv = [{"id": inventory_all[i].id, "inventory_name": inventory_all[i].inventory_name, "inventory_address": inventory_all[i].inventory_address}]
            else:
                active = ""          

            invs.append({"id": inventory_all[i].id, "inventory_name": inventory_all[i].inventory_name, "active": active, "inventory_address": inventory_all[i].inventory_address})

        invs = invs
        primary_inv = primary_inv
        return render(request, "inventory/create-category.html", {
        'invs': invs,
        'primary_inv': primary_inv[0],
        'inventory_length':len(invs),        
    })    

@login_required
def createitem(request):
    if request.method == 'POST':
        try:           
            category_id=request.POST["item-category"]
            userid = request.session.get('userid')   

            category = Category.objects.filter(id=category_id)
            inventory= Inventory.objects.filter(id=category[0].inventory_id)

            newitem=Item()
            newitem.inventory=inventory[0]
            newitem.item_category = category[0]
            newitem.item_name=request.POST["item_name"]
            newitem.item_manufacturer=request.POST["item_manufacturer"]
            newitem.item_color=request.POST["item_color"]
            newitem.item_price=request.POST["item_price"]
            newitem.item_weight=request.POST["item_weight"]
            newitem.item_weight_unit=request.POST["item_weight_unit"]
            newitem.item_Dimension=request.POST["item_Dimension"]
            newitem.item_storage_location=request.POST["item_storage_location"]
            if int(request.POST["item_quantity"]) <= 0:
                newitem.item_status='out'
            elif int(request.POST["item_quantity"]) < int(request.POST["item_min_quantity"]):
                newitem.item_status='min'
            else:
                newitem.item_status='available'
            newitem.item_quantity=request.POST["item_quantity"]
            newitem.item_min_quantity=request.POST["item_min_quantity"]
            newitem.save() 
        except Exception as e:
            return render(request, "inventory/login.html", {
                "message": e
            })                  
        return redirect('index')
    else:        
        
        inventory_all = request.session.get('invs')
        primary_inv = request.session.get('primary_inv')
        current_inv_id = request.session.get('current_inv_id')

        invs=[]
        cat_all=[]
        catobj=[]

        for i in range(len(inventory_all)):      
            if inventory_all[i]["id"]==current_inv_id:
                active = "active"
                primary_inv = [{"id": inventory_all[i]["id"], "name": inventory_all[i]["inventory_name"], "address": inventory_all[i]["inventory_address"]}]
            else:
                active = ""   

            invs.append({"id": inventory_all[i]["id"], "inventory_name": inventory_all[i]["inventory_name"], "active": active, "inventory_address": inventory_all[i]["inventory_address"]})

            c=Category.objects.filter(inventory_id=inventory_all[i]["id"])
            cat_all.append(c)

        for i in range(len(cat_all)):     
            for j in cat_all[i]:               
                cat=j
                catobj.append({"id":cat.id , "category_name": cat.category_name, "category_description":cat.category_description , "inventory_id" : cat.inventory_id})
      
        return render(request, "inventory/create-item.html", {
            'invs': invs,
            'primary_inv': primary_inv,
            'inventory_length':len(invs), 
            'cats':catobj,
            'cat_count': len(cat_all)       
        })   

@login_required
def change_inventory(request,inv_id):
   
    """ Swich to another inventory"""   
    request.session['current_inv_id'] = inv_id
    userid = request.session.get('userid')    
    inventory_all = request.session.get('invs')

    cat_all = Category.objects.filter(inventory_id=inv_id)
    invs=[]
    primary_inv={}

    for i in range(len(inventory_all)):
        if inventory_all[i]["id"]==inv_id:
            active = "active"
            primary_inv = [{"id": inventory_all[i]["id"], "name": inventory_all[i]["inventory_name"], "address": inventory_all[i]["inventory_address"]}]
        else:
            active = ""
            
        invs.append({"id": inventory_all[i]["id"], "inventory_name": inventory_all[i]["inventory_name"], "active": active, "inventory_address": inventory_all[i]["inventory_address"]})

    # Fetch all the items based on the selected inventory
    item  = Item.objects.filter(inventory_id=inv_id)
    return render(request, "inventory/index.html", {
        'invs': invs,
        'primary_inv': primary_inv[0],
        'items': item,
        'item_count' : len(item),
        'cats':cat_all,
        'cat_count': len(cat_all),
        'selectedstatus' : "All",
        'filteredcat':cat_all
    })

@login_required
def change_category(request, cat_id):    
    item  = Item.objects.filter(item_category_id=cat_id)
    user_id = request.session.get('userid')
    invs = request.session.get('invs')
    primary_inv = request.session.get('primary_inv')
    # All category
    cats = request.session.get('cats') 

    return render(request, "inventory/index.html", {
        'invs': invs,
        'primary_inv': primary_inv,
        'items': item,
        'item_count' : len(item),
        'cats':cats,
        'cat_count': len(cats),
        'filteredcat':cats,
        'selectedstatus' : "All"       
    })

@login_required
def change_status(request,status):
    pass

@login_required
def remove_inventory(request):
    
    # session data
    user_id = request.session.get('userid')
    invs = request.session.get('invs')
    cats = request.session.get('cats')
    primary_inv = request.session.get('primary_inv')

    if request.method == "POST":
        inventory=request.POST["inventory"]
        # Fetch all category of selected inventory
        cat_all = Category.objects.filter(inventory_id=inventory) 
        # Fetch all items of selected inventory
        items=Item.objects.filter(inventory_id=inventory)
        
        for i in items:
            item=Item.objects.filter(id=i.id)
            item.delete()

        for i in cat_all:
            cat=Category.objects.filter(id=i.id)
            cat.delete()

        inv=Inventory.objects.filter(id=inventory)
        inv.delete()
        return HttpResponseRedirect(reverse("index")) 
        
    else:
        return render(request, "inventory/remove-inventory.html", {
                    'invs': invs,
                    'primary_inv': primary_inv,
                    'inventory_length':len(invs)                 
                }) 

@login_required
def remove_category(request):
    # session data
    user_id = request.session.get('userid')
    invs = request.session.get('invs')
    cats = request.session.get('cats')
    primary_inv = request.session.get('primary_inv')

    catobj=[]
    for inv in invs:
        cat=Category.objects.filter(inventory_id=inv["id"])
        if len(cat) > 0:
            for j in cat:
                catobj.append({"id":j.id, "category_name": j.category_name, "category_description":j.category_description , "inventory_id" : j.inventory_id})
           

    if request.method == "POST":
        category=request.POST["item-category"]

        items=Item.objects.filter(item_category_id=category)
        
        for i in items:
            item=Item.objects.filter(id=i.id)
            item.delete()

        cat=Category.objects.filter(id=category)
        cat.delete()
        return HttpResponseRedirect(reverse("index")) 
        
    else:
        return render(request, "inventory/remove-category.html", {
                    'invs': invs,
                    'primary_inv': primary_inv,
                    'cats':catobj,
                    'inventory_length':len(invs)                 
                }) 

def remove_item(request):
     # session data
    user_id = request.session.get('userid')
    invs = request.session.get('invs')
    cats = request.session.get('cats')
    primary_inv = request.session.get('primary_inv')
    items=request.session.get('items')

    if request.method == "POST":
        item=request.POST["item-id"]        

        item=Item.objects.filter(id=item)        
        item.delete()
        return HttpResponseRedirect(reverse("index")) 
        
    else:
        return render(request, "inventory/remove-item.html", {
                    'invs': invs,
                    'primary_inv': primary_inv,
                    'cats':cats,
                    'items':items,
                    'inventory_length':len(invs)                 
                }) 

@login_required
def edit_inventory(request,inv_id):
    invs = request.session.get('invs')
    primary_inv = request.session.get('primary_inv')

    if request.method == "POST":
        user_id = request.session.get('userid')
        inventory_details = Inventory.objects.get(pk = inv_id)
        inventory_details.inventory_name = request.POST.get("inventory-name")
        inventory_details.inventory_address = request.POST.get("inventory-address")            
        inventory_details.save()           
           
        return HttpResponseRedirect(reverse("index")) 

    else:
        for i in invs:
            if i["id"] == inv_id:
                inventory_data = i
                break

        return render(request, "inventory/edit-inventory.html", {
                    'invs': invs,
                    'primary_inv': primary_inv,
                    'data':inventory_data
                }) 

@login_required
def edit_category(request,cat_id):
    invs = request.session.get('invs')
    primary_inv = request.session.get('primary_inv')
    cats = request.session.get('cats')
    if request.method == "POST":
        user_id = request.session.get('userid')
        cat_details = Category.objects.get(pk = cat_id)
        cat_details.category_name = request.POST.get("category-name")
        cat_details.category_description = request.POST.get("category-description")
        cat_details.inventory_id= request.POST.get("inventory")
        cat_details.save()           
           
        return HttpResponseRedirect(reverse("index")) 

    else:
        for i in cats:
            if i["id"] == int(cat_id): 
                category_data = i
                break
        return render(request, "inventory/edit-category.html", {
                    'invs': invs,
                    'primary_inv': primary_inv,
                    'data':category_data
                }) 

@login_required
def edit_item(request,item_id):
    userid = request.session.get('userid')     
    item_details = Item.objects.get(pk = item_id)
    item=Item.objects.filter(id=item_id)
   
    invs=[]
    primary_invs={}
    invs =  request.session.get('invs')
    primary_inv =  request.session.get('primary_inv')
    

    if request.method == "POST":
        # Submitted data
        item_details.item_category_id = request.POST["item-category"]
        item_details.item_name = request.POST.get('item_name')
        item_details.item_manufacturer = request.POST.get('item_manufacturer') 
        item_details.item_color =request.POST.get('item_color') 
        item_details.item_price =request.POST.get('item_price') 
        item_details.item_weight = request.POST.get('item_weight')
        item_details.item_weight_unit =request.POST.get('item_weight_unit')  
        item_details.item_Dimension =request.POST.get('item_Dimension') 
        item_details.item_storage_location =request.POST.get('item_storage_location') 
        item_details.item_quantity =request.POST.get('item_quantity')
        item_details.item_min_quantity =request.POST.get('item_min_quantity')  

        if not  request.POST.get('item_price'):
            item_details.item_price = 0

        if not  request.POST.get('item_quantity'):
            item_details.item_quantity = 0

        if not  request.POST.get('item_min_quantity'):
            item_details.item_min_quantity = 0

        if int(request.POST.get('item_quantity')) <= 0:
            item_details.item_status='out'
        elif int(request.POST.get('item_quantity')) >= int(request.POST.get('item_min_quantity')):
            item_details.item_status='available'
        else:
            item_details.item_status='min'

        item_details.save()
        return HttpResponseRedirect(reverse("index"))        
    else:
        catobj=[]
        for inv in invs:
            cat=Category.objects.filter(inventory_id=inv["id"])
            if len(cat) > 0:
                for j in cat:
                    catobj.append({"id":j.id, "category_name": j.category_name, "category_description":j.category_description , "inventory_id" : j.inventory_id})
            
        itemobj=[]        
        itemobj.append({
                    "id":item[0].id,
                    "item_name":item[0].item_name,
                    "item_manufacturer" : item[0].item_manufacturer,
                    "item_color" : item[0].item_color,
                    "item_price": item[0].item_price,
                    "item_weight" : item[0].item_weight,
                    "item_Dimension" : item[0].item_Dimension,
                    "item_storage_location":item[0].item_storage_location,
                    "item_status":item[0].item_status,
                    "inventory_id":item[0].inventory_id,
                    "item_category_id":item[0].item_category_id,
                    "item_min_quantity":item[0].item_min_quantity,
                    "item_quantity":item[0].item_quantity,
                    "item_weight_unit":item[0].item_weight_unit
                })
        item_data = itemobj
        return render(request, "inventory/edit-item.html", {
            'invs': invs,
            'primary_inv': primary_inv,
            'inventory_length':len(invs), 
            'cats':catobj,
            'cat_count': len(catobj),
            'data':item_data[0]
        }) 

def select_inventory(request):
    invs = request.session.get('invs')
    primary_inv = request.session.get('primary_inv')
    cats = request.session.get('cats')
    inv_id=request.POST.get("inventory")
    if request.method == "POST":
        link = "/edit-inventory/" + inv_id
        return redirect(link)  
    else:
        return render(request, "inventory/select-inventory.html", {
                    'invs': invs,
                    'primary_inv': primary_inv
                })

def select_category(request):
    invs = request.session.get('invs')
    primary_inv = request.session.get('primary_inv')
    cats=request.session.get('cats')
    cat_id=request.POST.get("category")
    catobj=[]
    for inv in invs:
        cat=Category.objects.filter(inventory_id=inv["id"])
        if len(cat) > 0:
            for j in cat:
                catobj.append({"id":j.id, "category_name": j.category_name, "category_description":j.category_description , "inventory_id" : j.inventory_id})
           
    if request.method == "POST":
        link = "/edit-category/" + cat_id
        return redirect(link)  
    else:
        return render(request, "inventory/select-category.html", {
                    'invs': invs,
                    'primary_inv': primary_inv,
                    'cats':catobj
                })

def select_item(request):
    invs = request.session.get('invs')
    primary_inv = request.session.get('primary_inv')
    cats=request.session.get('cats')
    items=request.session.get('items')
    item_id=request.POST.get("selecteditem")
    print("------------------------")
    print(invs)
    itemobj=[]
    catobj=[]
    for inv in invs:
        cat=Category.objects.filter(inventory_id=inv["id"])
        if len(cat) > 0:
            for j in cat:
                catobj.append({"id":j.id, "category_name": j.category_name, "category_description":j.category_description , "inventory_id" : j.inventory_id})
           
        item=Item.objects.filter(inventory_id=inv["id"])
        print(item)
        if len(item) > 0:
            for i in item:
                print(i)
                itemobj.append({
                    "id":i.id,
                    "item_name":i.item_name,
                    "item_manufacturer" : i.item_manufacturer,
                    "item_color" : i.item_color,
                    "item_price": i.item_price,
                    "item_weight" : i.item_weight,
                    "item_Dimension" : i.item_Dimension,
                    "item_storage_location":i.item_storage_location,
                    "item_status":i.item_status,
                    "inventory_id":i.inventory_id,
                    "item_category_id":i.item_category_id,
                    "item_min_quantity":i.item_min_quantity,
                    "item_quantity":i.item_quantity,
                    "item_weight_unit":i.item_weight_unit
                })
               
    if request.method == "POST":
        link = "/edit-item/" + item_id
        return redirect(link)  
    else:
        return render(request, "inventory/select-item.html", {
                    'invs': invs,
                    'primary_inv': primary_inv,
                    'cats':catobj,
                    'items':itemobj
                })

def apply_filter(request):
    invs = request.session.get('invs')
    primary_inv = request.session.get('primary_inv')
    cats_all=request.session.get('cats')
    items=request.session.get('items')
    selectedcategory=request.POST.get("category")
    selectedstatus=request.POST.get("status")
    searchitembyname=request.POST.get('searchitembyname')
    current_inv_id=request.session['current_inv_id']
    
    if request.method=="POST":        
        filter_item=[]
        filter_cat=[]
        filter_name=[]
        if selectedcategory == "" and selectedstatus == "":
            filter_cat=Category.objects.filter(inventory_id=current_inv_id)
            filter_item=Item.objects.filter(inventory_id=current_inv_id)
        else:
            if selectedcategory != "" and selectedstatus != "":
                filter_cat=Category.objects.filter(id=selectedcategory,inventory_id=current_inv_id)
                filter_item=Item.objects.filter(item_category_id=selectedcategory,item_status=selectedstatus,inventory_id=current_inv_id)
            elif selectedcategory != "":
                filter_cat=Category.objects.filter(id=selectedcategory,inventory_id=current_inv_id)
                filter_item=Item.objects.filter(item_category_id=selectedcategory,inventory_id=current_inv_id)
            elif selectedstatus != "":
                filter_cat=cats_all
                filter_item=Item.objects.filter(inventory_id=current_inv_id ,item_status=selectedstatus) 
            else:
                filter_cat=cats_all
                filter_item=items

        itembyname=[]
        if searchitembyname != "" and searchitembyname != None:
            for item in filter_item:
                if (selectedcategory == "" or selectedcategory == None) and (selectedstatus == "") : 
                           
                    if item.item_name.lower() == searchitembyname.lower():
                        itembyname.append(item)
                else:
                    if str(item.item_name).lower() == str(searchitembyname).lower():
                        itembyname.append(item)
                
            filter_item=itembyname
           
        if selectedstatus == "":
            selectedstatus = "All"
        if selectedcategory == "":
            selectedcategory = -1

        all_invs=[]    
        for i in range(len(invs)):      
            if invs[i]["id"]==current_inv_id:
                active = "active"
                primary_inv = [{"id": invs[i]["id"], "name": invs[i]["inventory_name"], "address": invs[i]["inventory_address"]}]
            else:
                active = ""
                
            all_invs.append({"id": invs[i]["id"], "inventory_name": invs[i]["inventory_name"], "active": active, "inventory_address": invs[i]["inventory_address"]})
        
        return render(request, "inventory/index.html", {
                    'invs': all_invs,
                    'primary_inv': primary_inv[0],
                    'cats':cats_all,
                    'items':filter_item,
                    'filteredcat':filter_cat,
                    'selectedcatid':int(selectedcategory),
                    'selectedstatus':selectedstatus,
                    'searchbyname' : searchitembyname
                })
    else:
        return render(request, "inventory/index.html", {
                    'invs': invs,
                    'primary_inv': primary_inv,
                    'cats':cats,
                    'items':items,
                    'filteredcat':cats,
                    'selectedstatus' : "All"     
                })

@login_required
def view_notification(request):
    # invs = request.session.get('invs')
    userid=request.session.get('userid')
    invs=Inventory.objects.filter(user_id=userid) 
    primary_inv = request.session.get('primary_inv')
    cats_all=request.session.get('cats')
    catobj=[]
    itemsobj=[]
    for inv in invs:
        cat=Category.objects.filter(inventory_id=inv.id)
        if len(cat) > 0:
            for j in cat:
                catobj.append({"id":j.id, "category_name": j.category_name, "category_description":j.category_description , "inventory_id" : j.inventory_id})
            items=Item.objects.filter(inventory_id=inv.id).exclude(item_status='available').order_by('item_category')
            for i in items:
                itemsobj.append({
                    "id":i.id,
                    "item_name":i.item_name,
                    "item_manufacturer" :i.item_manufacturer,
                    "item_color" : i.item_color,
                    "item_price": i.item_price,
                    "item_weight" : i.item_weight,
                    "item_Dimension" : i.item_Dimension,
                    "item_storage_location":i.item_storage_location,
                    "item_status":i.item_status,
                    "inventory_id":i.inventory_id,
                    "item_category_id":i.item_category_id,
                    "item_min_quantity":i.item_min_quantity,
                    "item_quantity":i.item_quantity,
                    "item_weight_unit":i.item_weight_unit
                })
    current_inv_id=request.session['current_inv_id']
    
  
    all_invs=[]
    
    for i in range(len(invs)):      
        if invs[i].id==current_inv_id:
            active = "active"
            primary_inv = [{"id": invs[i].id, "name": invs[i].inventory_name, "address": invs[i].inventory_address}]
        else:
            active = ""
            
        all_invs.append({"id": invs[i].id, "inventory_name": invs[i].inventory_name, "active": active, "inventory_address": invs[i].inventory_address})
    
    return render(request, "inventory/view-notification.html", {
                    'invs':invs,
                    'primary_inv':primary_inv[0],
                    'cats':catobj,
                    'items':itemsobj,
                    'item_count' : len(itemsobj),

                })

    